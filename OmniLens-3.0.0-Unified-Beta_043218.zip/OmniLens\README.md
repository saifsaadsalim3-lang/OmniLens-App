# OmniLens

**Version:** 3.0.0 Unified Beta  
**Copyright:** © 2026 Saif_S_Salim. All rights reserved.

This Android Studio project unifies the OmniLens 1.3.0, 2.0 stable, and main/v3
code lines. The primary dashboard contains the v3 security, vault, notification,
sector, camera, gallery, and watermarking workflow. The **Unified Capture &
Licensing** entry opens the retained 1.3/2.0 sector, licensing, photo, video,
escrow, and watermarking workflow.

## Build

Open the project root in Android Studio with JDK 17 and Android SDK 34 installed,
then sync Gradle and run the `app` configuration. The command-line equivalent is:

```text
gradle assembleDebug
```

The source archive does not include the Gradle wrapper binary, so either Android
Studio or a locally installed Gradle distribution is required for the first build.
