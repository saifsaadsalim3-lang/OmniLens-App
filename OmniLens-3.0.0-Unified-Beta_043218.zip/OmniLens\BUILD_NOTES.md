# Build and merge notes

## Unified project

- Product name: OmniLens
- Version: 3.0.0 Unified Beta (`versionCode` 30000)
- Namespace/application ID: `com.omnilens.omniguard`
- Copyright owner: Saif_S_Salim
- Android Gradle Plugin: 8.2.2
- Kotlin: 1.9.22
- Compile/target SDK: 34
- Minimum SDK: 24
- Java/Kotlin target: 17

## Merge summary

- The main/v3 dashboard is the launcher activity.
- The 1.3/2.0 sector, license-mode, photo/video, escrow, and watermarking flow is
  retained as `UnifiedCaptureActivity` and linked from the main dashboard.
- `LogoEngine`, `OmniWatermarkEngine`, sharing support, the verification server,
  private vault, application lock, notifications, custom sectors, and camera
  settings are retained.
- Manifest activity names, notification permission, and the FileProvider
  authority were reconciled.
- The invalid `res/layout` file was moved to
  `res/layout/legacy_dashboard.xml`.
- Duplicate/out-of-module FileProvider XML and the obsolete patch fragment were
  removed.

## Validation performed

- All XML files parsed successfully.
- All JSON files parsed successfully.
- No duplicate top-level Kotlin activity class names remain.
- Manifest includes the three expected activities.
- Gradle metadata and the unified version were checked statically.

An APK build was not run in the packaging environment because Java, Gradle,
Android Studio, and the Android SDK were not installed. Open the project in
Android Studio with JDK 17 and SDK 34, sync it, and run `assembleDebug`.
