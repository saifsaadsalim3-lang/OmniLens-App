# OmniLens 3.0.0 Unified Beta

Android application package: `com.omnilens.omniguard`

## Build
- JDK 17
- Android Gradle Plugin 8.2.2
- Gradle 8.2.1 or compatible
- compileSdk / targetSdk 34

Build using GitHub Actions or run:

```bash
gradle clean assembleDebug --no-configuration-cache --stacktrace
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

Copyright © 2026 Saif_S_Salim. All rights reserved.
